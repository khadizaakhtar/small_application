<div class="top_grid rs_top2">
    <?php
    foreach ($show_company as $k_icompany) {
        ?>
        <div class="col-md-3">
            <div class="grid1">
                <div class="view view-first">
                    <div class="index_img"><img width="400px !important;" height="500px !important;" src="<?php echo base_url() . "uploads/" . $k_icompany->company_logo; ?>" class="img-responsive" alt=""/></div>
                    <div class="sale">$2.980</div>
                    <div class="mask">
                        <div class="info"><i class="search"> </i> Show More</div>
                        <ul class="mask_img">
                            <li class="star"><img src="images/star.png" alt=""/></li>
                            <li class="set"><img src="images/set.png" alt=""/></li>
                            <div class="clearfix"> </div>
                        </ul>
                    </div>
                </div> 
                <i class="home"></i>
                <div class="inner_wrap">
                    <h3>2 bedroom house for rent in Dubai</h3>
                    <ul class="star1">
                        <h4 class="green">Vision Agency</h4>
                        <li><a href="#"> <img src="images/star1.png" alt="">(236)</a></li>
                    </ul>
                </div>
            </div>
        </div>
    <?php } ?>

    <div class="clearfix"> </div>
</div>
<div class="top_grid rs_top">
    <?php
    foreach ($show_company2 as $k_icompany) {
        ?>
        <div class="col-md-3">
            <div class="grid1">
                <div class="view view-first">
                    <div class="index_img"><img width="400px !important;" height="400px !important;" src="<?php echo base_url() . "uploads/" . $k_icompany->company_logo; ?>" class="img-responsive" alt=""/></div>
                    <div class="sale">$2.980</div>
                    <div class="mask">
                        <div class="info"><i class="search"> </i> Show More</div>
                        <ul class="mask_img">
                            <li class="star"><img src="images/star.png" alt=""/></li>
                            <li class="set"><img src="images/set.png" alt=""/></li>
                            <div class="clearfix"> </div>
                        </ul>
                    </div>
                </div> 
                <i class="home"></i>
                <div class="inner_wrap">
                    <h3>2 bedroom house for rent in Dubai</h3>
                    <ul class="star1">
                        <h4 class="green">Vision Agency</h4>
                        <li><a href="#"> <img src="images/star1.png" alt="">(236)</a></li>
                    </ul>
                </div>
            </div>
        </div>
    <?php } ?>                
    <div class="clearfix"> </div>
</div>

