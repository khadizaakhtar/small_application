<?php $this->load->view('includes/font_header'); ?>  

<div class="living_middle">
    <div class="container">
        <div class="col-md-4 wow fadeInLeft" data-wow-delay="0.4s">
            <ul class="feature">
                <li> <i class="icon-tick"></i></li>
                <li class="feature_right"><h4>Recent Posts</h4>
                     <?php 
                    foreach($recent_post as $v_post){                       
                    ?>
                    <ul>
                       <li class="category"><a href="<?php echo base_url();?>recent_post/<?php echo $v_post->post_id;?>"><?php echo $v_post->blog_title; ?></a></li>
                    </ul>
                    <?php } ?>
                </li>
                <div class="clearfix"></div>
            </ul>
            <ul class="feature">
                <li> <i class="icon-trophy"></i></li>
                <li class="feature_right"><h4>All Categories</h4>
                    <?php 
                    foreach($all_published_category as $v_category){                       
                    ?>
                    <ul>
                       <li class="category"><a href="#"><?php echo $v_category->category_name; ?></a></li>
                    </ul>
                    <?php } ?>
                </li>
                <div class="clearfix"></div>
            </ul>            
            <ul class="feature">
                <li> <i class="icon-audio"></i></li>
                <li class="feature_right"><h4>Recent Comments</h4>
                    <p>
                        Lorem ipsum dolor sit amet, vix erat audiam ei. Cum doctus civibus efficiantur in. 
                    </p>
                </li>
                <div class="clearfix"></div>
            </ul>
            <ul class="feature last_grid">
                <li> <i class="icon-video"></i></li>
                <li class="feature_right"><h4>Video Lessons</h4>
                    <p>
                        Lorem ipsum dolor sit amet, vix erat audiam ei. Cum doctus civibus efficiantur in. Nec id tempor imperdiet deterruisset, doctus volumus explicari qui ex, appareat similique an usu.
                    </p>
                </li>
                <div class="clearfix"></div>
            </ul>
        </div>       
        <div class="col-md-8 wow fadeInRight" data-wow-delay="0.4s">
             <?php echo $blog_maincontent;?>  
        </div>        
    </div>
</div>
<div class="living_bottom">
    <div class="container">
        <h2 class="title block-title">Latest Posts</h2>
         <?php 
    foreach($last_two_post as $v_lpost){
    ?>
        <div class="col-md-6 post_left wow fadeInLeft" data-wow-delay="0.4s">
            <div class="mask1"><img src="<?php echo base_url()."blog_uploads/".$v_lpost->image;?>" alt="image" class="img-responsive zoom-img" /></div>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque cursus, sem eget sagittis sagittis, nisl magna sodales eros, ut feugiat velit velit non turpis. Cras eu nibh dapibus justo fringilla   <a href="#">More</a></p>
            <div class="divider"></div>
            <p class="field-content">30 Sep 2014</span></p>
        </div>
        <?php }?>
    </div>
</div>

<?php $this->load->view('includes/font_footer'); ?> 